package com.plugin.record_mp3.record.port;


import com.plugin.record_mp3.record.RecordStatus;

/**
 * Created by hujie on 16/5/25.
 */
public class SimpleRecordListener implements RecordListener {
    @Override
    public void onRecorderStatusChange(RecordStatus status) {

    }

    @Override
    public void onFileNotFound() {

    }

    @Override
    public void onPermissionError() {

    }

    @Override
    public void onComplete() {

    }

    @Override
    public void onIOExecption() {

    }

    @Override
    public void onRecordMayUsed() {

    }
}
